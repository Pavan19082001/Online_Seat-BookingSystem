package com.example.demo.Exception;

public class UserNotFoundException extends RuntimeException{

}
